<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Login | Gaming Community</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      background: url('background3.jpg') no-repeat center center fixed;
      background-size: cover;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    .login-card {
      background: rgba(255, 255, 255, 0.05);
      backdrop-filter: blur(12px);
      border: 1px solid rgba(255, 255, 255, 0.1);
      box-shadow: 0 0 30px rgba(0, 255, 255, 0.1);
      border-radius: 20px;
      padding: 40px;
      width: 100%;
      max-width: 400px;
      color: #fff;
    }

    .login-card h2 {
      text-align: center;
      color: #00bfff;
      margin-bottom: 30px;
      font-weight: bold;
    }

    .form-control {
      background: rgba(255, 255, 255, 0.05);
      border: 1px solid #444;
      color: #fff;
    }

    .form-control::placeholder {
      color: #ccc;
    }

    .form-control:focus {
      background-color: rgba(0, 0, 0, 0.4);
      border-color: #00bfff;
      box-shadow: 0 0 0 0.2rem rgba(0, 191, 255, 0.25);
      color: #0ff;
    }

    .btn-login {
      background: #00bfff;
      border: none;
      width: 100%;
      padding: 12px;
      color: #fff;
      font-weight: bold;
      border-radius: 10px;
      transition: 0.3s ease;
    }

    .btn-login:hover {
      background: #009acd;
    }

    .link-light {
      text-align: center;
      display: block;
      margin-top: 15px;
      color: #aaa;
    }

    .link-light:hover {
      color: #0ff;
    }

    @media (max-width: 500px) {
      .login-card {
        padding: 30px 20px;
      }
    }
  </style>
</head>
<body>

  <div class="login-card">
    <h2> Login</h2>
    <form method="POST" action="login.php">
      <div class="mb-3">
        <input type="text" class="form-control" name="username" placeholder="Username" required>
      </div>
      <div class="mb-3">
        <input type="password" class="form-control" name="password" placeholder="Password" required>
      </div>
      <button type="submit" class="btn btn-login">Login</button>
    </form>
    <a href="register.php" class="link-light">Don't have an account? Register</a>
  </div>

</body>
</html>
