<?php
session_start();

// CONNECT TO DATABASE
$conn = new mysqli("localhost", "root", "", "gamehub");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// ADD GAME
if (isset($_POST['add'])) {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $image = $_POST['image'];

    $stmt = $conn->prepare("INSERT INTO games (title, description, image) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $title, $description, $image);
    $stmt->execute();
    $stmt->close();
}

// UPDATE GAME
if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $title = $_POST['title'];
    $description = $_POST['description'];
    $image = $_POST['image'];

    $stmt = $conn->prepare("UPDATE games SET title=?, description=?, image=? WHERE id=?");
    $stmt->bind_param("sssi", $title, $description, $image, $id);
    $stmt->execute();
    $stmt->close();
}

// DELETE GAME
if (isset($_POST['delete'])) {
    $id = $_POST['id'];

    $stmt = $conn->prepare("DELETE FROM games WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
}

// FETCH GAMES
$result = $conn->query("SELECT * FROM games");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Game Management Panel | Gaming Community</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      background: url('background3.jpg') no-repeat center center fixed;
      background-size: cover;
      color: #fff;
    }

    .container {
      max-width: 1000px;
      background: rgba(0, 0, 0, 0.85);
      backdrop-filter: blur(12px);
      border-radius: 15px;
      padding: 40px;
      margin: 60px auto;
      box-shadow: 0 0 30px rgba(0,255,255,0.1);
    }

    h1 {
      text-align: center;
      color: #00bfff;
      font-weight: bold;
      margin-bottom: 30px;
    }

    .form-control,
    textarea {
      background: rgba(255, 255, 255, 0.05);
      border: 1px solid #444;
      color: #fff;
    }

    .form-control::placeholder {
      color: #bbb;
    }

    .form-control:focus {
      background-color: rgba(0, 0, 0, 0.4);
      color: #0ff;
      border-color: #00bfff;
      box-shadow: 0 0 0 0.2rem rgba(0,191,255,0.25);
    }

    .btn-success {
      background-color: #28a745;
      border: none;
    }

    .btn-success:hover {
      background-color: #1e7e34;
    }

    .btn-update {
      background-color: #0d6efd;
      border: none;
      color: white;
    }

    .btn-update:hover {
      background-color: #0a58ca;
    }

    .btn-delete {
      background-color: #dc3545;
      border: none;
      color: white;
    }

    .btn-delete:hover {
      background-color: #bb2d3b;
    }

    .table {
      color: #fff;
      background: rgba(255, 255, 255, 0.02);
    }

    .table img {
      width: 100px;
      height: auto;
      border-radius: 10px;
      object-fit: cover;
    }

    thead.table-dark {
      background-color: rgba(0, 0, 0, 0.5);
    }

    hr {
      border-color: #444;
    }
  </style>
</head>
<body>

  <div class="container">
    <h1>🎮 Game Management Panel</h1>

    <!-- Add Game Form -->
    <form method="POST" action="games.php">
      <input type="text" name="title" class="form-control" placeholder="Game Title" required>
      <textarea name="description" class="form-control" placeholder="Game Description" required></textarea>
      <input type="text" name="image" class="form-control" placeholder="Image filename (e.g. cyberpunk.jpg)" required>
      <button type="submit" name="add" class="btn btn-success mt-2">Add Game</button>
    </form>

    <hr>

    <!-- Display Existing Games -->
    <h4 class="mt-4 mb-3">🎲 Existing Games</h4>
    <table class="table table-striped table-bordered text-center">
      <thead class="table-dark">
        <tr>
          <th>Game Title</th>
          <th>Description</th>
          <th>Image</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
          <tr>
            <form method="POST" action="games.php">
              <td><input name="title" class="form-control" value="<?= htmlspecialchars($row['title']) ?>"></td>
              <td><textarea name="description" class="form-control"><?= htmlspecialchars($row['description']) ?></textarea></td>
              <td><img src="images/<?= htmlspecialchars($row['image']) ?>" alt="Game Image"></td>
              <td>
                <input type="hidden" name="id" value="<?= $row['id'] ?>">
                <input name="image" class="form-control mb-2" value="<?= htmlspecialchars($row['image']) ?>">
                <button type="submit" name="update" class="btn btn-update btn-sm mb-1">Update</button>
                <button type="submit" name="delete" class="btn btn-delete btn-sm">Delete</button>
              </td>
            </form>
          </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>

</body>
</html>

<?php $conn->close(); ?>
